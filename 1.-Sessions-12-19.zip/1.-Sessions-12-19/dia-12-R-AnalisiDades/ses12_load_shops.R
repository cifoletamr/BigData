if(!require('dplyr')) {
  install.packages('dplyr')
  library('dplyr')
}
cargar_fichero <- function (nombre_fichero) {

   start_time <- Sys.time()
   my_path = "C:/Users/mati/cursopy/BigData/dat/shops"
   my_file = file.path(my_path, nombre_fichero)
   datos = read.csv(my_file)
   print(nrow(datos))
   end_time <- Sys.time()
   print(end_time - start_time)
   datos
}


df20 = cargar_fichero("sh-1-2020.csv")
df21 = cargar_fichero("sh-1-2021.csv")

start_time <- Sys.time()
tot = rbind (df20, df21)
nrow(tot)
end_time <- Sys.time()
