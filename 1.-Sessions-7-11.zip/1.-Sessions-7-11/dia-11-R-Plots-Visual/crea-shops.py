from random import randint, uniform
# 3  botigues * 10 anys * 12 mesos * 30 dies * 12 hores * 6 intervals 
# * 5 venedors * 100 productes =  388.800.000,00 registres 
shops = 3
years = 10
months = 12
days = 30
hours = 12
minutes = 60
vendors = 5
products = 100
def obre_arxiu(shop,  year) :
    f = open(f"./dat/shops/sh-{shop}-{year}.csv", "w", encoding="UTF-8")
    f.write ("shop,year,month,day,time,vendor,id_prod,quanty, price\n")
    return (f)

def crea_linea(f, shop, year, month, day) :
    linea = ("{:02d},"*4).format(shop, year, month, day)
    for hour in range(9, hours +9) :
        for minut in range (0, minutes, 10) :
            for vendor in range (1, vendors +1) :
                for product in range (1, products+1) :
                    linea1 = "{:02d}:{:02d},".format(hour, minut)
                    linea1 += ("{:02d},"*3).format(vendor, product, randint(1,5))
                    linea1 += "{3.1}".format(uniform(1,10))  #price
                    f.write (linea+linea1+'\n')

# -------- valors provisionals 
shops = 2
years = 2
months = 2
days = 2
hours = 2
minutes = 20
vendors = 2
products = 2

for shop in range(1, shops+1) :
    for year in range(2020, years+2020) :
        f = obre_arxiu(shop,  year)
        for month in range(1, months+1) :
            for day in range(1, days+1) :
                crea_linea(f, shop, year, month, day)
        f.close()
#------------------------------------
                


